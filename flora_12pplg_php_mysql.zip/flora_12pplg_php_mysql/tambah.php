<?php 
include 'lib/koneksi.php'; 
?>
<!DOCTYPE html>
<html>
<head>
    <title>Tambah Data Siswa</title>
    
    <style>
        body {
            font-family: Arial, sans-serif;
            background: linear-gradient(135deg, #3b82f6, #06b6d4);
            margin: 0;
            padding: 0;
        }
        .container {
            background: white;
            width: 400px;
            margin: 60px auto;
            padding: 25px;
            border-radius: 12px;
            box-shadow: 0px 0px 12px rgba(0,0,0,0.2);
        }
        h2 {
            text-align: center;
            color: #0ea5e9;
            margin-bottom: 20px;
        }
        label {
            font-weight: bold;
            color: #333;
        }
        input {
            width: 100%;
            padding: 10px;
            border: 2px solid #0ea5e9;
            border-radius: 8px;
            font-size: 14px;
            margin-top: 5px;
        }
        button {
            background: #0ea5e9;
            color: white;
            font-weight: bold;
            padding: 10px;
            border: none;
            border-radius: 8px;
            width: 100%;
            margin-top: 15px;
            cursor: pointer;
            transition: 0.3s;
            font-size: 15px;
        }
        button:hover {
            background: #0284c7;
        }
    </style>
</head>
<body>

<div class="container">
    <h2>Form Tambah Data Siswa</h2>

    <form method="POST">
        <label>Nama:</label>
        <input type="text" name="nama" required>

        <br><br>

        <label>Kelas:</label>
        <input type="text" name="kelas" required>

        <br><br>

        <label>Jurusan:</label>
        <input type="text" name="jurusan" required>

        <br>

        <button type="submit" name="simpan">Simpan</button>
    </form>

    <?php
    if (isset($_POST['simpan'])) {
        $nama = $_POST['nama'];
        $kelas = $_POST['kelas'];
        $jurusan = $_POST['jurusan'];

        $query = $pdo->prepare("INSERT INTO siswa (nama, kelas, jurusan) VALUES (?, ?, ?)");
        $query->execute([$nama, $kelas, $jurusan]);

        // Redirect ke tampil.php setelah berhasil
        echo "<script>alert('Data berhasil disimpan!'); window.location='tampil.php';</script>";
    }
    ?>

</div>

</body>
</html>
