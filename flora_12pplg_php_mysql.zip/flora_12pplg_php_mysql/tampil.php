<?php 
include 'lib/koneksi.php'; 
?>
<!DOCTYPE html>
<html>
<head>
    <title>Data Siswa</title>

    <style>
        body {
            font-family: Arial, sans-serif;
            background: #f0f9ff;
        }
        .container {
            width: 700px;
            background: white;
            margin: 60px auto;
            padding: 20px;
            border-radius: 12px;
            box-shadow: 0px 0px 12px rgba(0,0,0,0.15);
        }
        h2 {
            text-align: center;
            color: #0284c7;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            border-radius: 6px;
            overflow: hidden;
        }
        th {
            background: #0284c7;
            color: white;
            padding: 12px 8px;
        }
        td {
            padding: 10px 8px;
            border-bottom: 1px solid #ddd;
        }
        tr:hover {
            background: #f1f5f9;
        }
        .btn-tambah {
            display: inline-block;
            margin-bottom: 15px;
            background: #0ea5e9;
            color: white;
            padding: 10px 14px;
            text-decoration: none;
            border-radius: 8px;
            font-weight: bold;
        }
        .btn-tambah:hover {
            background: #0369a1;
        }
    </style>

</head>
<body>

<div class="container">
    <h2>Daftar Siswa</h2>

    <a class="btn-tambah" href="tambah.php">+ Tambah Data</a>

    <table>
        <tr>
            <th>No</th>
            <th>Nama</th>
            <th>Kelas</th>
            <th>Jurusan</th>
        </tr>

        <?php
        $no = 1;
        $stmt = $pdo->query("SELECT * FROM siswa ORDER BY id DESC");
        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
            echo "
            <tr>
                <td>{$no}</td>
                <td>{$row['nama']}</td>
                <td>{$row['kelas']}</td>
                <td>{$row['jurusan']}</td>
            </tr>
            ";
            $no++;
        }
        ?>
    </table>

</div>

</body>
</html>
